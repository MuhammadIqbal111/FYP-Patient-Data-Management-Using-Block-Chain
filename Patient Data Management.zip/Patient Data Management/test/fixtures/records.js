
const records = [{
    providedName: false,
    name: '',
    patient: '0xc5fdf4076b8f3a5357c5e395ab970b5b54098fef',
    hospital: '0x627306090abab3a6e1400e9345bc60c78a8bef57',
    admissionDate: '1',
    dischargeDate: '5',
    visitReason: '0123',
}, {
    providedName: false,
    name: '',
    patient: '0x821aea9a577a9b44299b9c15c88cf3087f3b5544',
    hospital: '0xf17f52151ebef6c7334fad080c5704d77216b732',
    admissionDate: '3',
    dischargeDate: '6',
    visitReason: '0124',
}, {
    providedName: false,
    name: '',
    patient: '0x821aea9a577a9b44299b9c15c88cf3087f3b5544',
    hospital: '0xf17f52151ebef6c7334fad080c5704d77216b732',
    admissionDate: '6',
    dischargeDate: '8',
    visitReason: '0125',
}]

export default records
